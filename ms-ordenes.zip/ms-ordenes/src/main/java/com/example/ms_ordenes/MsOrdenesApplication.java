package com.example.ms_ordenes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsOrdenesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsOrdenesApplication.class, args);
	}

}
