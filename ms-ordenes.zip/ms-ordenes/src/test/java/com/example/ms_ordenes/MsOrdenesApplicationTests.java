package com.example.ms_ordenes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOrdenesApplicationTests {

	@Test
	void contextLoads() {
	}

}
